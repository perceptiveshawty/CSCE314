readme:

Sachin Chanchani
828004948

resources:

https://wiki.haskell.org/Monad
https://people.engr.tamu.edu/hlee42/csce314/lec09-haskell-parsers.pdf
https://www.cmi.ac.in/~spsuresh/teaching/prgh15/papers/monadic-parsing.pdf
https://eli.thegreenplace.net/2017/deciphering-haskells-applicative-and-monadic-parsers/
https://wiki.haskell.org/Lifting#Monad_lifting
https://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.122.1785&rep=rep1&type=pdf
https://www.seas.upenn.edu/~cis552/15fa/lectures/Parsers.html
Haskell Tutorials/StackOverflow
